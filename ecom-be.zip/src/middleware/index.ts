const accountSid=process.env.account_sid;
const authToken=process.env.auth_token;
const serviceSid=process.env.service_sid;
const client=require('twilio')(accountSid,authToken);
import jwt from 'jsonwebtoken'
const secret_key:any=process.env.secret_key
const login_verify=async (req:any,res:any,next:any)=>{
    try{
        let result=await client.verify
        .services(process.env.service_sid)
        .verificationChecks
        .create({
            to:req.body.number,
            channel:'sms',
            code:req.body.code
        })
        //console.log(result);
        if(result.valid){
            next();
        }
    }
    catch(err){
        res.status(400).json(err.message)
    }
}
function verifyAccessToken(req:any,res:any,next:any){
    const authorization=req.headers.authorization;
    if(authorization){
        const token=authorization.split(' ')[1];
        jwt.verify(token,secret_key,(err:any,payload:any)=>{
            if(err){
                res.status(401).send({message:'Invalid Token'})
            }
            else {
                req.user=payload,
                next()
            }
        })
    }
    else{
        res.status(401).send({message:'No Token'})
    }
    
}

export={login_verify,verifyAccessToken}