import mongoose from 'mongoose';

const productSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    original_price:{
        type:Number,
        required:true
    },
    current_price:{
        type:Number,
    },
    rating:{
        type:Number,
        required:true
    },
    image:{
        type:String,
        required:true
    },
    category:{
        type:String,
        required:true
    },
    description:{
        type:Array
    },
    gender:{
        type:String
    },
    offer:{
        type:String
    },
    brand:{
        type:String
    },
    count_in_stock:{
        type:Number,
        default:1
    }

})
module.exports = mongoose.model('product',productSchema)