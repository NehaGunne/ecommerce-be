import mongoose from 'mongoose';

const reviewSchema=new mongoose.Schema({
    productId:{
        type:String,
        required:true
    },
    userId:{
        type:String,
        required:true
    },
    username:{
        type:String,
    },
    comment:{
        type:String,
        required:true
    },
    rating:{
        type:Number
    }
},
{
    timestamps:true
}
)
module.exports = mongoose.model('review',reviewSchema)