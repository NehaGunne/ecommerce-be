import mongoose from 'mongoose';
import validator from 'validator';
import bcrypt from 'bcrypt';
const userSchema=new mongoose.Schema<any>({
    username:{
        type:String,
        required:[true,'! please enter a username']
    },
    email:{
        type:String,
        validate: [validator.isEmail, 'invalid email' ],
        required:[true,'! please enter a email'],
        unique:true
    },
    number:{
        type:Number,
        required:[true,'! please enter a phone number'],
    },
    password:{
        type:String,
        required:[true,'! please enter a password'],
        minlength:[6,'min length should be 6 characters']
    },
    cart:{
        type:Array
    },
    isAdmin:{
        type:Boolean,
        default:false
    },
    isSeller:{
        type:Boolean,
        default:false
    }
})
userSchema.statics.login=async function(email:any,password:any){
    const user=await this.findOne({email})
    if(user){
       const auth= await bcrypt.compare(password,user.password);
       if(auth){
           return user
       }else{
           throw Error('! Incorrect Password')
       }

    }else{
        throw Error('! Incorrect Email')
    }
}
userSchema.pre('save',async function(next:any){
    const salt=await bcrypt.genSalt();
    this.password=await bcrypt.hash(this.password,salt)
    next();
})
module.exports=mongoose.model('user',userSchema);