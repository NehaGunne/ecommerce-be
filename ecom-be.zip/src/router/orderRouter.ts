import express from 'express'
import orderController from '../controller/orderController'
import middleWare from '../middleware'
const router=express.Router();
router.get('/',orderController.getAllOrders);
router.post('/',middleWare.verifyAccessToken,orderController.createOrder);
router.get('/:_id',middleWare.verifyAccessToken,orderController.getUserOrders);
router.get('/created-order/:_id',middleWare.verifyAccessToken,orderController.getCreatedOrder);
router.get('/config/paypal',orderController.getPaypalId);
router.post('/:_id/pay',middleWare.verifyAccessToken,orderController.updateOrder);
export=router;