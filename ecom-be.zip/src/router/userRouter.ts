import express from 'express'
import userController from '../controller/userController';
import middleWare from '../middleware';
const router=express.Router();
router.get('/',userController.getUsers);
router.get('/sellers',userController.getAllSellers);
router.post('/otp',userController.send_otp);
router.post('/signup',middleWare.login_verify,userController.createUser);
router.post('/login',userController.login_post);
router.get('/logout',userController.logOut);
router.get('/cart/:_id',userController.getAllCart);
router.post('/cart',userController.addToCart);
router.delete('/cart',userController.delFromCart);
export =router;
