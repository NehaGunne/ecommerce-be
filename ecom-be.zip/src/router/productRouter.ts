import express from 'express'
import productController from '../controller/productController'
const router=express.Router();
router.get('/',productController.getAllProducts);
router.post('/',productController.addProduct)
router.get('/category',productController.getAllCategories);
router.get('/category/:category',productController.searchByCategory);
router.get('/search',productController.textSearch);
export =router;
