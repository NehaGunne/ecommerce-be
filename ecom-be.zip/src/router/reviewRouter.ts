import express from 'express'
import reviewController from '../controller/reviewController'
const router=express.Router();
router.get('/:_id',reviewController.getReviewsOfProduct);
router.post('/',reviewController.addReview);
export=router