import env from 'dotenv';
env.config();
import express from 'express'
import cors from 'cors';
import mongoose from 'mongoose';
import userRouter from './router/userRouter';
import productRouter from './router/productRouter';
import orderRouter from './router/orderRouter';
import reviewRouter from './router/reviewRouter'; 
import path from 'path';

const connStr=`mongodb+srv://${process.env.db_user}:${process.env.db_password}@cluster0.qggfo.mongodb.net/${process.env.db_database}?retryWrites=true&w=majority`
const app=express();
/* app.use(express.static(path.join(__dirname,'build'))) */
app.use(express.json()); 
app.use(cors());

mongoose.connect(connStr,{ useNewUrlParser: true , useUnifiedTopology: true ,useFindAndModify:false});
const con=mongoose.connection;

con.on('open',()=>{
    console.log("connected to mongodb");
})
con.on('error',(err)=>{ 
    console.log('mongoose err:',err.message)
})
/* app.get('/',(req,res)=>{ 
    res.sendFile(path.join(__dirname,'build','index.html'))
}) */
app.use('/products',productRouter);
app.use('/users',userRouter);
app.use('/orders',orderRouter);
app.use('/reviews',reviewRouter); 
app.listen(process.env.port,()=>{
    console.log(`server started at port ${process.env.port}`);
    
})




