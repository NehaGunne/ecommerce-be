const review:any=require('../model/reviewSchema')

const getReviewsOfProduct=async(req:any,res:any)=>{
    try{
        const result=await review.find({productId:req.params._id}).sort({createdAt:-1}).exec();
        if(result){
            res.status(200).json(result)
        }
        else{
            res.status(400).json({message:'There are no reviews!'})
        } 
    }
    catch(err){
        res.status(500).json(err.message)
    }

}

const addReview=async(req:any,res:any)=>{
    const newReview=new review({...req.body})
    try{
        const result=await newReview.save();
        res.status(201).json({result,message:'new review added'})
       
    }
    catch(err){
        res.status(400).json(err.message)
    }

}

export={getReviewsOfProduct,addReview}