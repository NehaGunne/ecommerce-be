const order = require('../model/orderSchema');
const user=require('../model/userSchema');
const getAllOrders=async(req:any,res:any)=>{
    try{
        let orders=await order.find();
        res.status(200).json(orders);
    }
    catch(err){
        res.status(500).send(err.message);
    }
}
const createOrder = async (req: any, res: any) => {
    try {
        if (req.body.orderItems.length === 0) {
            res.status(400).send('cart is empty')
        }
        else {
            const order1 = new order({
                orderItems: req.body.orderItems,
                shippingAddress: req.body.shippingAddress,
                paymentMethod: req.body.paymentMethod,
                itemsPrice: req.body.itemsPrice,
                shippingPrice: req.body.shippingPrice,
                taxPrice: req.body.taxPrice,
                totalPrice: req.body.totalPrice,
                user: req.body.user._id
            })
            const result = await order1.save();
            let updatedCart=await user.findOneAndUpdate({_id:req.body.user._id},{cart:[]})
            res.status(201).send({ message: 'new order created', order: result })
        }
    } catch (err) {
        console.log(err.message)
        res.status(400).send(err.message)
    }
}

const getUserOrders=async(req:any,res:any)=>{
    try{
        let result=await order.find({user:req.params._id})
        res.status(200).json(result)
    }
    catch(err){
        console.log(err.message)
        res.status(400).send(err.message);
    }

}
const getCreatedOrder=async(req:any,res:any)=>{
    try{
        let result=await order.findById(req.params._id)
        if(!result){
            res.status(404).send({message:'order not found'});
        }else{
            res.status(200).json(result)
        }
    }
    catch(err){
        console.log(err.message)
        res.status(400).send(err.message);
    }

}

const getPaypalId=async(req:any,res:any)=>{
    res.json(process.env.paypal_client_id||'sb')

}

const updateOrder=async(req:any,res:any)=>{
    try{

        const order1=await order.findById(req.params._id);
        if(order1){
            order1.isPaid=true;
            order1.paidAt=Date.now();
            order1.paymentResult={
                id:req.body.id,
                status:req.body.status,
                update_time:req.body.update_time,
                email_address:req.body.email_address
            };
            const updatedOrder=await order1.save();
            res.status(201).json({message:'Order paid',order:updatedOrder})
        }else{
            res.status(404).send({message:'order not found'})
        }
    }
    catch(err){
        res.status(400).send({message:err.message})
    }

}
export ={ getAllOrders,createOrder,getUserOrders,getCreatedOrder,getPaypalId,updateOrder }