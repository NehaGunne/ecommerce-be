const product:any=require('../model/productSchema');

const getAllProducts=async function(req:any,res:any){
    try{
            const products=await product.find(req.query)
            res.status(200).json(products)
        }
        catch(err){
            res.json(err.message);
    }
}
const addProduct=async(req:any,res:any)=>{
    const newProduct=new product({
        ...req.body
        });
    try{
        const p1=await newProduct.save();
        res.status(201).json(p1);

    }catch(err){
        res.status(400).json(err.message);
    }

}
const getAllCategories=async(req:any,res:any)=>{
    try{
        const result=await product.find().distinct('category');
        res.status(200).json(result)
    }
    catch(err){
        res.status(400).send(err.message)
    }
}
const searchByCategory=async(req:any,res:any)=>{
    try{
        const p=await product.find({category:req.params.category})
        res.status(200).json(p)
    }
    catch(err){
        res.status(400).send(err.message)
    }
}

const textSearch=async(req:any,res:any)=>{
    try{
        const result=await product.find({$or:[
            {brand:{$regex:new RegExp(req.query.q,"i")}},
            {name:{$regex:new RegExp(req.query.q,"i")}},
            {description:{$regex:new RegExp(req.query.q,"i")}},
            {gender:{$regex:new RegExp(req.query.q,"i")}},
            {category:{$regex:new RegExp(req.query.q,"i")}}
         ]})
         res.status(200).json(result)
    }
    catch(err){
        res.status(400).send(err.message)
    }

}

export={getAllProducts,addProduct,getAllCategories,searchByCategory,textSearch}