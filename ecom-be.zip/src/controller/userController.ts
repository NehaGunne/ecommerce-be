const user:any=require('../model/userSchema')
import jwt from 'jsonwebtoken'
//import {v4} from 'uuid'
const secret_key:any=process.env.secret_key
const accountSid=process.env.account_sid;
const authToken=process.env.auth_token;
const serviceSid=process.env.service_sid;
const client=require('twilio')(accountSid,authToken);

const handleErrors=(err:any)=>{
    let errors:any={email:'',password:'',username:'',number:''};
    if(err.message==='! Incorrect Password'){
        errors.password='! Incorrect Password'
    }
    if(err.message==='! Incorrect Email'){
        errors.email='! Incorrect Email'
    }
    if(err.code===11000){
        errors.email='this email is already registered'
        return errors;
    }
    if(err.message.includes('user validation failed')){
        Object.values(err.errors).forEach(({properties}:any)=>{
            errors[properties.path]=properties.message;
        })
    }
    return errors;
}

const maxAge=24*60*60;
const createToken=(id:any)=>{
    return jwt.sign({id},secret_key,{
        expiresIn:maxAge
    });
}
const getUsers=async function(req:any,res:any){
    try{
        const users=await user.find();
        res.status(200).json(users);
    }catch(err){
        res.status(400).json(err.message);
    }
}
const getAllSellers=async function(req:any,res:any){
    try{
        const sellers=await user.find({isSeller:true});
        res.status(200).json(sellers);
    }catch(err){
        res.status(400).json(err.message);
    }
}

const createUser=async(req:any,res:any)=>{
    const newUser=new user({
        username: req.body.username,
        email:req.body.email,
        number:req.body.number,
        password:req.body.password,
        isSeller:req.body.isSeller

    });
    try{
        const u1=await newUser.save();
        const token=createToken(u1._id);
        res.cookie('jwt',token,{httpOnly:true,maxAge:maxAge*1000})
        res.status(201).json({user:u1,token:token});
    }catch(err){
        const errors=handleErrors(err);
        console.log(err.message)
        res.status(400).json({errors});
    }

}
const send_otp=async(req:any,res:any)=>{
    try{
        let result=await client.verify
        .services(process.env.service_sid)
        .verifications
        .create({
            to:req.body.number,
            channel:'sms'
        })
        console.log(result)
        res.status(200).json(result)
    }
    catch(err){
        console.log(err.message);
        res.status(400).json(err.message)
    }
}
const login_post=async(req:any,res:any)=>{
    const {email,password}=req.body;
    try{
        const authUser=await user.login(email,password);
        const token=createToken(authUser._id);
        res.cookie('jwt',token,{maxAge:maxAge*1000,httpOnly:true})
        res.status(200).json({user:authUser,token:token})

    }
    catch(err){
        const errors=handleErrors(err)
        //console.log(errors)
        res.status(400).send({errors});
    }
}
const logOut=async(req:any,res:any)=>{
    try{
        res.cookie('jwt','abcd',{httpOnly:true,maxAge:1})
        res.status(200).send('logged out')
    }catch(err){
        res.status(400).send(err);
    }
}

const getAllCart=async(req:any,res:any)=>{
    try{
        const result=await user.find({_id:req.params._id},{_id:false,cart:true});
        res.status(200).json(result);
    }
    catch(err){
        res.status(400).send(err.message);
    }
}

const addToCart=async(req:any,res:any)=>{
    try{
       // const uniqueId = v4();
       if(req.body.product){
        let result=await user.updateOne({_id:req.body._id},{$push:{cart:{...req.body.product}}})
        res.status(201).send(result)
        }
    }
    catch(err){
        res.status(400).json(err)
    }
}
const delFromCart=async(req:any,res:any)=>{
    try{
        const result=await user.updateOne( 
            { _id:req.body._id }, // your query, usually match by _id
            { $pull: { cart:  { _id:req.body.product_id} } } , // item(s) to match from array you want to pull/remove
            { safe:true,multiple:true} // set this to true if you want to remove multiple elements.
        )
        res.status(200).send(result);
    }
    catch(err){
        res.status(400).json(err);
    }
}
export={getUsers,createUser,login_post,getAllCart,send_otp,getAllSellers,
    addToCart,delFromCart,logOut};